from Gempa import *

gempa1 = Gempa('banten', 1.2)
gempa1.dampak()
print()
print()

gempa2 = Gempa('Palu', 6.1)
gempa2.dampak()
print()
print()

gempa3 = Gempa('cianjur', 5.6)
gempa3.dampak()
print()
print()

gempa4 = Gempa('jayapura', 3.3)
gempa4.dampak()
print()
print()

gempa5 = Gempa('garut', 4.0)
gempa5.dampak()
print()
print()

