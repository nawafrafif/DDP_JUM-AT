print("=====SOAL NO1=====")
def celsius_ke_fahrenheit(celcius):
    fahrenheit = (celcius * 9/5) + 32
    return fahrenheit
    
print(celsius_ke_fahrenheit(0))
print(celsius_ke_fahrenheit(100))
print("=====SOAL NO2=====")
def is_genap(bilangan):
    hasil = bilangan % 2 == 0

    return hasil

print(is_genap(4))
print(is_genap(7))
print("=====SOAL NO3=====")
def cek_lulus(nilai):
    if nilai >= 70:
        return "lulus"

    else:
        return "gagal"

print(cek_lulus(80))
print(cek_lulus(60))
print("=====SOAL NO4=====")
def bilangan_ganjil(n):
    return[i for i in range(1, n+1) if i % 2 != 0]
print(bilangan_ganjil(20))